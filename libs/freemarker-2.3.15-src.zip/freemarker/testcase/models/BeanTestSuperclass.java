package freemarker.testcase.models;

public class BeanTestSuperclass
{
    public Integer getSomething() {
        return 42;
    }
    
    public void setSomething(Integer x) {
        
    }
}
